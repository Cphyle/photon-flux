package space.t3space;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by elk85 on 4/29/2017.
 */

public class cog1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cog1);
    }
}
